API Reference
=============

.. toctree::
   :maxdepth: 2

   api/terminal.rst
   api/shell_terminals.rst
   api/math_terminals.rst
   api/batch.rst

