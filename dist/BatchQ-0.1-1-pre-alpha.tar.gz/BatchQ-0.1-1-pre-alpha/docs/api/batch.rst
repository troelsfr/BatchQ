Batch Model
===========

.. automodule:: batchq.core.batch
   :members:

